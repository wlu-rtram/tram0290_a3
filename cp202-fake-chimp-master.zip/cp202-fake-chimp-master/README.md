# Assignment 3 - Question 2

These are the files provided for Q2 of Assignment 3.

The FakeChimpRegistrationFormSpecification.pdf document has all the information required to complete the solution to this question.

Pay attention to the details: the colours, and fonts.

The are two logos: one color and the other black and white. The spec explains how to use them. Take a look at the test-logo.html file for a hint on to reduce the size of the image to fit the spec.
